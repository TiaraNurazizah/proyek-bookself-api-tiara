/* eslint-disable linebreak-style */
// eslint-disable-next-line linebreak-style
const books = [];

// eslint-disable-next-line eol-last
module.exports = books;